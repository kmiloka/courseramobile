import * as SQLite from 'expo-sqlite';

const db = SQLite.openDatabase('little_lemon.db');

export const createTable = () => {
  db.transaction(tx => {
    tx.executeSql(
      'CREATE TABLE IF NOT EXISTS menu (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, price REAL, description TEXT, image TEXT, category TEXT);'
    );
  });
};

export const getMenuItems = () => {
  return new Promise((resolve, reject) => {
    db.transaction(tx => {
      tx.executeSql('SELECT * FROM menu;', [], (_, { rows }) => {
        resolve(rows._array);
      }, (_, error) => {
        reject(error);
      });
    });
  });
};

export const saveMenuItems = (menu) => {
  db.transaction(tx => {
    tx.executeSql('DELETE FROM menu;');
    menu.forEach(item => {
      tx.executeSql(
        'INSERT INTO menu (name, price, description, image, category) VALUES (?, ?, ?, ?, ?);',
        [item.name, item.price, item.description, item.image, item.category]
      );
    });
  });
};

export const filterMenuByCategories = (categories) => {
  return new Promise((resolve, reject) => {
    if (categories.length === 0) {
      getMenuItems().then(resolve).catch(reject);
    } else {
      const placeholders = categories.map(() => '?').join(',');
      db.transaction(tx => {
        tx.executeSql(
          `SELECT * FROM menu WHERE category IN (${placeholders});`,
          categories,
          (_, { rows }) => {
            resolve(rows._array);
          },
          (_, error) => {
            reject(error);
          }
        );
      });
    }
  });
};
