import React, { useEffect, useState } from 'react';
import { View, Text, Image, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SQLite from 'expo-sqlite';
import CategoryList from './CategoryList';
import Banner from './Banner';
import { createTable, getMenuItems, saveMenuItems, filterMenuByCategories, filterMenuByDishName } from '../database';

const db = SQLite.openDatabase('little_lemon.db');

const Home = () => {
  const [menuItems, setMenuItems] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const navigation = useNavigation();

  useEffect(() => {
    createTable();
    const fetchData = async () => {
      try {
        const storedMenu = await getMenuItems();
        if (storedMenu.length > 0) {
          setMenuItems(storedMenu);
        } else {
          const response = await fetch('https://github.com/Meta-Mobile-Developer-PC/Working-With-Data-API/blob/main/menu.json?raw=true');
          const data = await response.json();
          setMenuItems(data.menu);
          saveMenuItems(data.menu);
        }
      } catch (error) {
        console.error(error);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const fetchFilteredMenu = async () => {
      try {
        const filteredMenu = await filterMenuByCategories(selectedCategories);
        setMenuItems(filteredMenu);
      } catch (error) {
        console.error(error);
      }
    };

    fetchFilteredMenu();
  }, [selectedCategories]);

  useEffect(() => {
    const fetchFilteredMenu = async () => {
      try {
        const filteredMenu = await filterMenuByDishName(searchQuery, selectedCategories);
        setMenuItems(filteredMenu);
      } catch (error) {
        console.error(error);
      }
    };

    fetchFilteredMenu();
  }, [searchQuery]);

  const renderItem = ({ item }) => (
    <View style={styles.menuItem}>
      <Image
        source={{ uri: `https://github.com/Meta-Mobile-Developer-PC/Working-With-Data-API/blob/main/images/${item.image}?raw=true` }}
        style={styles.image}
      />
      <View style={styles.menuItemText}>
        <Text style={styles.name}>{item.name}</Text>
        <Text style={styles.description}>{item.description}</Text>
        <Text style={styles.price}>${item.price.toFixed(2)}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Little Lemon</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Image
            source={require('../assets/avatar.png')}
            style={styles.avatar}
          />
        </TouchableOpacity>
      </View>
      <Banner searchQuery={searchQuery} setSearchQuery={setSearchQuery} />
      <CategoryList selectedCategories={selectedCategories} setSelectedCategories={setSelectedCategories} />
      <FlatList
        data={menuItems}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  menuItem: {
    flexDirection: 'row',
    marginBottom: 16,
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 8,
  },
  menuItemText: {
    flex: 1,
    marginLeft: 16,
  },
  name: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 14,
    color: 'gray',
  },
  price: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 8,
  },
});

export default Home;
