import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Image, TouchableOpacity, CheckBox } from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as ImagePicker from 'expo-image-picker';
import { TextInputMask } from 'react-native-masked-text';

const Profile = () => {
  const route = useRoute();
  const navigation = useNavigation();
  const { firstName, email } = route.params;
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [avatar, setAvatar] = useState(null);
  const [notifications, setNotifications] = useState({
    email: false,
    sms: false,
  });

  useEffect(() => {
    const loadProfileData = async () => {
      try {
        const profileData = await AsyncStorage.getItem('profile');
        if (profileData) {
          const { lastName, phoneNumber, avatar, notifications } = JSON.parse(profileData);
          setLastName(lastName);
          setPhoneNumber(phoneNumber);
          setAvatar(avatar);
          setNotifications(notifications);
        }
      } catch (e) {
        console.error(e);
      }
    };

    loadProfileData();
  }, []);

  const handleSaveChanges = async () => {
    const profileData = {
      firstName,
      lastName,
      email,
      phoneNumber,
      avatar,
      notifications,
    };

    try {
      await AsyncStorage.setItem('profile', JSON.stringify(profileData));
      alert('Profile saved successfully!');
    } catch (e) {
      console.error(e);
    }
  };

  const handleLogout = async () => {
    try {
      await AsyncStorage.clear();
      navigation.navigate('Onboarding');
    } catch (e) {
      console.error(e);
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      setAvatar(result.uri);
    }
  };

  const renderAvatar = () => {
    if (avatar) {
      return <Image source={{ uri: avatar }} style={styles.avatar} />;
    } else {
      const initials = `${firstName.charAt(0)}${lastName.charAt(0)}`;
      return (
        <View style={styles.placeholderAvatar}>
          <Text style={styles.initials}>{initials}</Text>
        </View>
      );
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="First Name"
        value={firstName}
        editable={false}
      />
      <TextInput
        style={styles.input}
        placeholder="Last Name"
        value={lastName}
        onChangeText={setLastName}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        editable={false}
      />
      <TextInputMask
        type={'custom'}
        options={{
          mask: '(999) 999-9999',
        }}
        value={phoneNumber}
        onChangeText={setPhoneNumber}
        style={styles.input}
        placeholder="Phone Number"
        keyboardType="numeric"
      />
      <TouchableOpacity onPress={pickImage}>
        {renderAvatar()}
      </TouchableOpacity>
      <View style={styles.checkboxContainer}>
        <CheckBox
          value={notifications.email}
          onValueChange={(value) => setNotifications({ ...notifications, email: value })}
        />
        <Text style={styles.label}>Email Notifications</Text>
      </View>
      <View style={styles.checkboxContainer}>
        <CheckBox
          value={notifications.sms}
          onValueChange={(value) => setNotifications({ ...notifications, sms: value })}
        />
        <Text style={styles.label}>SMS Notifications</Text>
      </View>
      <Button title="Save Changes" onPress={handleSaveChanges} />
      <Button title="Logout" onPress={handleLogout} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    justifyContent: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 12,
  },
  placeholderAvatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'gray',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  initials: {
    color: 'white',
    fontSize: 24,
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  label: {
    marginLeft: 8,
  },
});

export default Profile;
