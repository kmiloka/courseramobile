import React from 'react';
import { View, Text, Image, TextInput, StyleSheet } from 'react-native';

const Banner = ({ searchQuery, setSearchQuery }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Little Lemon</Text>
      <Text style={styles.subtitle}>Mediterranean Cuisine</Text>
      <Text style={styles.description}>
        Welcome to Little Lemon, a charming neighborhood bistro that serves simple food and classic cocktails in a lively but casual environment.
      </Text>
      <Image
        source={require('../assets/banner.jpg')}
        style={styles.image}
      />
      <TextInput
        style={styles.searchBar}
        placeholder="Search for a dish..."
        value={searchQuery}
        onChangeText={setSearchQuery}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 18,
    color: 'gray',
  },
  description: {
    fontSize: 14,
    marginVertical: 8,
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 8,
    marginVertical: 8,
  },
  searchBar: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 8,
  },
});

export default Banner;
